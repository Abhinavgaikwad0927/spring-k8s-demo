package com.example.spring_k8s_demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringK8sDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
